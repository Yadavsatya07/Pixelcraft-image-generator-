"use client";
import React from "react";

function MainComponent() {
  const [prompt, setPrompt] = React.useState("");
  const [style, setStyle] = React.useState("realistic");
  const [imageUrl, setImageUrl] = React.useState(
    () => localStorage.getItem("lastGeneratedImage") || ""
  );
  const [loading, setLoading] = React.useState(false);
  const [previousImages, setPreviousImages] = React.useState([]);
  const [selectedImage, setSelectedImage] = React.useState(null);
  const [currentPage, setCurrentPage] = React.useState("home");

  const generateImage = async () => {
    setLoading(true);
    try {
      const fullPrompt = `${prompt}, style: ${style}`;
      const response = await fetch(
        `/integrations/dall-e-3/?prompt=${encodeURIComponent(fullPrompt)}`,
        {
          method: "GET",
        }
      );
      const result = await response.json();
      const newImageUrl = result.data[0];
      setImageUrl(newImageUrl);
      localStorage.setItem("lastGeneratedImage", newImageUrl);
      setPreviousImages([
        ...previousImages,
        { url: newImageUrl, title: prompt },
      ]);
    } catch (error) {
      console.error("Error generating image:", error);
    }
    setLoading(false);
  };

  const downloadImage = (url) => {
    const link = document.createElement("a");
    link.href = url;
    link.download = "generated-image.png";
    link.click();
  };

  const renderContent = () => {
    switch (currentPage) {
      case "home":
        return (
          <div className="flex flex-col items-center justify-center py-8 px-4 md:px-0">
            <p className="text-lg mb-8 text-center max-w-[600px]">
              Discover the power of AI-generated images. Create stunning visuals
              with just a few clicks.
            </p>
            <div className="flex items-center mb-8">
              <h1 className="text-5xl font-bold mr-4">Image Generator</h1>
              <i className="fas fa-image text-5xl"></i>
            </div>
            <input
              type="text"
              name="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full md:w-[500px] p-3 mb-4 bg-[#1E1E1E] text-white border-none rounded-lg"
              placeholder="Enter a prompt..."
            />
            <select
              name="style"
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              className="w-full md:w-[500px] p-3 mb-4 bg-[#1E1E1E] text-white border-none rounded-lg"
            >
              <option value="realistic">Realistic</option>
              <option value="toon">Toon</option>
              <option value="cinematic">Cinematic</option>
            </select>
            <button
              onClick={generateImage}
              disabled={loading}
              className="w-full md:w-[500px] p-3 mb-4 bg-[#2C2C2C] text-white rounded-lg hover:bg-[#3A3A3A] transition"
            >
              {loading ? "Generating..." : "Generate Image"}
            </button>
            {loading && (
              <div className="flex items-center justify-center mt-4">
                <svg
                  className="animate-spin h-5 w-5 text-white"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 5L1 5 1 10 4 7z"
                  />
                </svg>
                <span className="ml-2">Image generating...</span>
              </div>
            )}
            {imageUrl && (
              <div className="flex flex-col items-center">
                <img
                  src={imageUrl}
                  alt="Generated"
                  className="w-full md:w-[400px] mb-4 rounded-lg shadow-lg"
                />
                <button
                  onClick={() => downloadImage(imageUrl)}
                  className="w-full md:w-[500px] p-3 bg-[#2C2C2C] text-white rounded-lg hover:bg-[#3A3A3A] transition"
                >
                  Download Image
                </button>
              </div>
            )}
            <h2 className="text-3xl font-bold mt-8">
              Previous Generated Images
            </h2>
            <div className="flex flex-wrap justify-center mt-4">
              {previousImages.length > 0 &&
                previousImages.map((img, index) => (
                  <div key={index} className="m-2">
                    <img
                      src={img.url}
                      alt={`Previous ${index}`}
                      className="w-[100px] h-[100px] cursor-pointer rounded-lg shadow-md"
                      onClick={() => setSelectedImage(img.url)}
                    />
                  </div>
                ))}
            </div>
            {selectedImage && (
              <div className="flex flex-col items-center mt-4">
                <img
                  src={selectedImage}
                  alt="Selected"
                  className="w-full md:w-[400px] rounded-lg shadow-lg"
                />
                <div className="flex mt-2">
                  <button
                    onClick={() => downloadImage(selectedImage)}
                    className="p-3 mx-2 bg-[#2C2C2C] text-white rounded-lg hover:bg-[#3A3A3A] transition"
                  >
                    Download
                  </button>
                  <button
                    className="p-3 mx-2 bg-[#2C2C2C] text-white rounded-lg hover:bg-[#3A3A3A] transition"
                    onClick={() => alert(`Share ${selectedImage}`)}
                  >
                    Share
                  </button>
                </div>
              </div>
            )}
            <h2 className="text-3xl font-bold mt-8">Pre-Generated Images</h2>
            <div className="flex flex-wrap justify-center mt-4">
              {[
                "/images/cityscape.png",
                "/images/mountain.png",
                "/images/beach.png",
                "/images/forest.png",
                "/images/desert.png",
                "/images/space.png",
                "/images/abstract.png",
                "/images/portrait.png",
                "/images/architecture.png",
                "/images/animals.png",
              ].map((img, index) => (
                <div key={index} className="m-2">
                  <img
                    src={img}
                    alt={`Pre-generated ${index}`}
                    className="w-[100px] h-[100px] cursor-pointer rounded-lg shadow-md"
                    onClick={() => setSelectedImage(img)}
                  />
                </div>
              ))}
            </div>
          </div>
        );
      case "about":
        return (
          <div className="p-8 max-w-[800px] mx-auto">
            <h1 className="text-5xl font-bold mb-4 text-center">
              About PixelCraft
            </h1>
            <p className="text-lg mb-4 text-center">
              PixelCraft is an innovative platform that leverages AI technology
              to generate stunning images from simple text prompts. Our mission
              is to make creativity accessible to everyone.
            </p>
            <p className="text-lg text-center">
              Whether you're a designer, artist, or just someone who loves
              visuals, PixelCraft is here to help you bring your ideas to life.
            </p>
          </div>
        );
      case "contact":
        return (
          <div className="p-8 max-w-[800px] mx-auto">
            <h1 className="text-5xl font-bold mb-4 text-center">Contact Us</h1>
            <p className="text-lg mb-4 text-center">
              We'd love to hear from you! Whether you have questions, feedback,
              or just want to say hello, feel free to reach out.
            </p>
            <p className="text-lg text-center">Email: support@pixelcraft.com</p>
            <p className="text-lg text-center">Phone: (123) 456-7890</p>
            <p className="text-lg text-center">
              Visit our website:{" "}
              <a
                href="https://lcsatya.blogspot.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-500 hover:underline"
              >
                lcsatya.blogspot.com
              </a>
            </p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#121212] text-white">
      <nav className="flex justify-between items-center p-4 bg-[#1E1E1E] shadow-md">
        <div className="text-2xl font-bold">PixelCraft</div>
        <div className="space-x-4">
          <button
            className="hover:underline"
            onClick={() => setCurrentPage("home")}
          >
            Home
          </button>
          <button
            className="hover:underline"
            onClick={() => setCurrentPage("about")}
          >
            About
          </button>
          <button
            className="hover:underline"
            onClick={() => setCurrentPage("contact")}
          >
            Contact
          </button>
        </div>
      </nav>
      {renderContent()}
      <footer className="p-4 bg-[#1E1E1E] text-center shadow-inner">
        <p>&copy; 2024 All rights reserved by Lcsatya</p>
      </footer>
    </div>
  );
}

export default MainComponent;